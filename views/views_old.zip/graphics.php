<h1>Graficos</h1>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/graphics/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Relação de Produção - Extrusão</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Relação de Limpeza de Maquina</strong>
	</a>
</div>
