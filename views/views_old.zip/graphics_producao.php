<style type="text/css">
	h1{
		color: blue;
	}
	fieldset{
		font-weight: bold;
	}
	input[type=date]{
		width: 400px;
	}
</style>
<h1 align="center">Grafico Produção - Extrusão</h1>
<form onsubmit="return openPopup(this)">
<fieldset>
	<legend>Filtro de data</legend>
	Data
	<input type="date" name="data1" value="<?php echo date('Y-m-d');?>">
	Entre
	<input type="date" name="data2" value="<?php echo date('Y-m-d');?>">
	<input type="submit" value="GERAR">
</fieldset>

</form>

<script type="text/javascript" src="<?=BASE_URL?>/assets/js/script_graphics_producao.js"></script>