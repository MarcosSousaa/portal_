<h1 style="text-align: center;">Indústria Bandeirante de Plásticos</h1>
<?php switch($info_template['name']['name']){
case 'COMPRAS' : 
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/records">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Registros Portaria</strong>
	</a>
</div>
<?php
    break;
    case 'PORTARIA ADMIN':
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/records">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Registros Portaria</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Veículos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/chaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_chaves.png" alt="" height="60">
		<br><br>
		<strong>Chaves</strong>
	</a>
</div>

<?php
    break;
    case 'PORTARIA':
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/records">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Registros Portaria</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Veículos</strong>
	</a>
</div>

<?php
    break;
    case 'EXTRUSAO':
?>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Perda</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Limpeza</strong>
	</a>
</div>

<?php
    break;
    case 'QUALIDADE':
?>


<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Perda</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Limpeza</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/operador">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_operador.png" alt="" height="60">
		<br><br>
		<strong>Operador</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_reports.png" alt="" height="60">
		<br><br>
		<strong>Relatorios</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/graphics">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_graphics.png" alt="" height="60">
		<br><br>
		<strong>Graficos</strong>
	</a>
</div>

<?php 
	break;
	case 'ACABAMENTO':
	case 'PRANDI':
	case 'IMPRESSAO':
	case 'MISTURA/RECUPERADORA':
	case 'EXTRUSAO':
	case 'TUBETE':
	case 'DISCO':
?>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Limpeza</strong>
	</a>
</div>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Perda</strong>
	</a>
</div>

<?php
    break;
    case 'PRODUCAO ADMIN':
?>


<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Perda</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Limpeza</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/operador">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_operador.png" alt="" height="60">
		<br><br>
		<strong>Operador</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_reports.png" alt="" height="60">
		<br><br>
		<strong>Relatorios</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/graphics">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_graphics.png" alt="" height="60">
		<br><br>
		<strong>Graficos</strong>
	</a>
</div>

<?php
	break;
	default :
?>	
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/records">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Registros Portaria</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Veículos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/chaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_chaves.png" alt="" height="60">
		<br><br>
		<strong>Chaves</strong>
	</a>
</div>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Lançamento Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/producao/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Lançamento Perda</strong>
	</a>
</div>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Limpeza de Máquinas</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/operador">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_operador.png" alt="" height="60">
		<br><br>
		<strong>Operador de Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_reports.png" alt="" height="60">
		<br><br>
		<strong>Relatorios</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/graphics">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_graphics.png" alt="" height="60">
		<br><br>
		<strong>Graficos</strong>
	</a>
</div>

<?php }?>




