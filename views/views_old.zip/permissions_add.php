<h1>Permissões - Adicionar</h1>

<form method="POST">
    
    <label for="name">Nome da Permissão</label>
    <input type="text" name="name"><br><br>
    
    <input type="submit" value="Adicionar">
    
</form>