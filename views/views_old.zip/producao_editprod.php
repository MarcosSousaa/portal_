<link href="<?= BASE_URL ?>/assets/css/producao.css" rel="stylesheet"/>
<h1 align="center">Producao - Editar</h1><br>
<style type="text/css">
	input[type=text]{
		width: 100px;
	}
</style>
<?php if (isset($error_msg) && !empty($error_msg)) : ?>
    <div class="warn"><?= $error_msg ?></div>
<?php endif; ?>
<form method="POST">	
<div class="painel_model">
	<h3><strong class="title">Nº Extrusora Produzida: </strong> <?= $producao_info['extrusora'] ; ?>
		<strong class="title">Turno: </strong> <?= $turno[$producao_info['turno']] ; ?>
     	<strong class="title"> Nome Operador:  </strong> <?= $producao_info['operador'] ;?>
	    
	</h3>
	<h3>
	    <strong class="title">Data Produção:</strong>  
	    <input type="date" name="data_prod" required value="<?php echo date('Y-m-d', strtotime($producao_info['data_prod'])); ?>">     
	    <strong class="title">Início:</strong>
	    <input type="text" name="hrini" id="hrini" value="<?= $producao_info['hri']; ?>">
	    <br>
	       <strong class="title">Situação:</strong>
       		<input type="radio" name="aprovacaoini" id="aprovacaoini" value="1" <?= ($producao_info['situacaoini'] == 'Aprovado') ? 'checked="checked"' : ''?>>
            <label for="aprovacaoini">Aprovado</label>
            <input type="radio" name="aprovacaoini" id="reprovacaoini" value="2" <?= ($producao_info['situacaoini'] == 'Reprovado') ? 'checked="checked"' : ''?>>
            <label for="reprovacaoini">Reprovado</label>
	    <br>
	    <strong class="title">Data Finalizada:</strong>
	    <input type="date" name="data_f" required value="<?php echo date('Y-m-d', strtotime($producao_info['data_f'])); ?>">
	    <strong class="title">Fim:</strong> <input type="text" name="hrfim" id="hrfim" value="<?= $producao_info['hrf']; ?>">
	    <br>
	    <strong class="title">Situação:</strong>
 		<input type="radio" id="aprovacaofim" name="aprovacaofim" value="1" <?= ($producao_info['situacaofim'] == 'Aprovado') ? 'checked="checked"' : ''?>>
        <label for="aprovacaofim">Aprovado</label>
        <input type="radio" id="reprovacaofim" name="aprovacaofim" value="2" <?= ($producao_info['	situacaofim'] == 'Reprovado') ? 'checked="checked"' : ''?>>
        <label for="reprovacaofim">Reprovado</label>            
	</h3>
	<hr>
	<h3>
		<strong class="title">Pedido:</strong>
		<input type="text" name="pedido" id="pedido" value="<?= $producao_info['pedido']; ?>">
		<strong class="title">Ordem:</strong> 
		<input type="text" name="ordem" id="ordem" value="<?= $producao_info['ordem']; ?>">
		<strong class="title">Lote Interno:</strong>
		<input type="text" name="lote" id="lote" value="<?= $producao_info['lote'];?>">
	    <strong class="title">Rpm:</strong>
	    <input type="text" name="rpm" id="rpm" value="<?= $producao_info['rpm'];?>">
	</h3>
	<h3><strong class="title">Peso Bob</strong>
		<input type="text" name="peso_bob" id="peso_bob" value="<?= number_format($producao_info['pesobob'],3,",","."); ?>">
	    <strong class="title">Quantidade Produzida:</strong>
	    <input type="number" name="quantidade" id="quantidade" value="<?= $producao_info['qtdbob']; ?>">
	    <strong class="title">Total Produzida:</strong>
	    <input type="text"  name="total" id="total" readonly="" value="<?= number_format($producao_info['totalbob'],3,",",".");?> "><hr>
	    <strong class="title">Largura:</strong>
	    <input type="text" name="larg" id="larg" value="<?= $producao_info['larg'];?>">
	    <strong class="title">Espessura:</strong>
	    <input type="text" name="esp" id="esp" value="<?= $producao_info['esp'];?> ">
	    <strong class="title">Metragem:</strong>
	    <input type="text" name="metrag" id="metrag" value="<?= $producao_info['metrag'];?>    "> 
	</h3>
</div>

	<fieldset class="novo-fieldset">
		<legend>Dados Adicionais</legend>
		<label>Sobra BOB Qtd.</label>
		<input type="number" name="sobrabob" value="<?= (isset($producao_info['perdabob'])) ? $producao_info['perdabob'] : ''; ?>">
		<label>Sobra BOB KG</label>			
		<input type="text" name="sobrabobkg" id="sobrabobkg" value="<?= (isset($producao_info['perdakg'])) ? $producao_info['perdakg'] : ''; ?>"><br>		
	</fieldset>
	<br>
	<input type="submit" name="" value="ATUALIZAR">	
	<a class="button" href="<?= BASE_URL?>/producao">VOLTAR</a>
</form>
<script type="text/javascript" src="<?= BASE_URL ?>/assets/js/script_producao_add.js"></script>