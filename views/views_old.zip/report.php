<h1>Relatórios</h1>
<?php switch($acesso['name']){
case 'COMPRAS' : 
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/recebimentoColeta">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Coleta-Recebimentos</strong>
	</a>
</div>
<?php 
	break;
	case 'PORTARIA ADMIN' :
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/entradaSaidaVeiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Entrada Saída Veículos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/recebimentoColeta">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Coleta-Recebimentos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/controleChaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Controle de Chaves Retiradas-Devolvidas</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/chaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_chaves.png" alt="" height="60">
		<br><br>
		<strong>Relação Chaves</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Relação Veiculos</strong>
	</a>
</div>

<?php 
	break;
	case 'PORTARIA' :
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/entradaSaidaVeiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Entrada Saída Veículos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/recebimentoColeta">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Coleta-Recebimentos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/controleChaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Controle de Chaves Retiradas-Devolvidas</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/chaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_chaves.png" alt="" height="60">
		<br><br>
		<strong>Relação Chaves</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Relação Veiculos</strong>
	</a>
</div>

<?php
	break;
	case 'QUALIDADE' :
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Relação de Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Relação de Perda</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Relação de Limpeza de Maquina</strong>
	</a>
</div>

<?php
	break;
	case 'PRODUCAO ADMIN' :
?>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Relação de Produção</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Relação de Perda</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Relação de Limpeza de Maquina</strong>
	</a>
</div>

<?php 
	break;
	default :
?>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/entradaSaidaVeiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Entrada Saída Veículos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/recebimentoColeta">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Relação Coleta-Recebimentos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/controleChaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_ent_sai.png" alt="" height="60">
		<br><br>
		<strong>Controle de Chaves Retiradas-Devolvidas</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/chaves">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_chaves.png" alt="" height="60">
		<br><br>
		<strong>Relação Chaves</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/veiculos">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_veiculos.png" alt="" height="60">
		<br><br>
		<strong>Relação Veiculos</strong>
	</a>
</div>

<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/producao">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_producao.png" alt="" height="60">
		<br><br>
		<strong>Relação de Produção</strong>
	</a>
</div>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/perda">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_perda.png" alt="" height="60">
		<br><br>
		<strong>Relação de Perda</strong>
	</a>
</div>
<div class="report_item">
	<a href="<?php echo BASE_URL;?>/reports/limpeza">
		<img src="<?php echo BASE_URL;?>/assets/images/icons/icon_report_limpeza.png" alt="" height="60">
		<br><br>
		<strong>Relação de Limpeza de Maquina</strong>
	</a>
</div>
<?php } ?>