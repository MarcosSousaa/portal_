<h1>Relatórios de Chaves</h1>

<form method="POST" onsubmit="return openPopup(this)">

    <div class="report-grid-4">
        Nome da Chave:<br>
        <input type="text" name="chave_name">
    </div>

    <div class="report-grid-4">
        Nome do Local:<br>
        <input type="text" name="local_name">
    </div>

    <div style="clear: both"></div>

    <div style="text-align: center">
        <input type="submit" value="Gerar Relatório">
        <a class="button" href="<?= BASE_URL?>/reports">VOLTAR</a>
    </div>

</form>

<script type="text/javascript" src="<?=BASE_URL?>/assets/js/script_report_chaves.js"></script>