<h1>Relatórios de Limpeza de Maquina</h1>

<form onsubmit="return openPopup(this)">

    <div class="report-grid-4">
        Data Inicial<br>
        <input type="date" name="limpeza_data_inicial" value="<?php echo date("Y-m-d") ?>">
    </div>

    <div class="report-grid-4">
        Data Final<br>
        <input type="date" name="limpeza_data_final" value="<?php echo date("Y-m-d") ?>">
    </div>

    <div class="report-grid-4">
        Departamento<br>
        <select id="dep" name="dep">
            <option disabled selected>Escolha um departamento</option>
            <option value="ACA">Acabamento</option>
            <option value="EXT">Extrusão</option>
            <option value="IMP">Impressora</option>
            <option value="MIS">Mistura</option>   
            <option value="PRA">Prandi</option>
            <option value="TUB">Tubete</option>                    
        </select>    
    </div>

    <div class="report-grid-4">
        Maquina<br>
        <select id="maq" name="maq">
            <option disabled selected>Escolha uma maquina</option>
            <option value="EST01">Estufa e Seladora</option>
            <option value="EXT01">Extrusora 01</option>
            <option value="EXT02">Extrusora 02</option>
            <option value="EXT03">Extrusora 03</option>
            <option value="EXT04">Extrusora 04</option>
            <option value="EXT05">Extrusora 05</option>        
            <option value="GRA01">Granuladeira 01</option>
            <option value="GRA02">Granuladeira 02</option>
            <option value="GRA03">Granuladeira 03</option>
            <option value="IMP01">Impressora 01</option>
            <option value="IMP02">Impressora 02</option>
            <option value="MIS01">Misturador 01</option>
            <option value="MIS02">Misturador 02</option>
            <option value="PRA01">Prandi 01</option>
            <option value="PRA02">Prandi 02</option>
            <option value="RAC01">Rachadeira 01</option>
            <option value="RAC02">Rachadeira 02</option>
            <option value="REB01">Rebobinadeira 01</option>
            <option value="REB02">Rebobinadeira 02</option>
            <option value="REB03">Rebobinadeira 03</option>
            <option value="REB04">Rebobinadeira 04</option>
            <option value="REB05">Rebobinadeira 05</option>
            <option value="REB06">Rebobinadeira 06</option>
            <option value="REB07">Rebobinadeira 07</option>
            <option value="TUB08">Rebobinadeira 08</option>
            <option value="TUB09">Rebobinadeira 09</option>
            <option value="TUB10">Rebobinadeira 10</option>
            <option value="TUB11">Rebobinadeira 11</option>
            <option value="TUB12">Rebobinadeira 12</option>
            <option value="TUB13">Rebobinadeira 13</option>
            <option value="TUB14">Rebobinadeira 14</option>
            <option value="TUB15">Rebobinadeira 15</option>
            <option value="TUB16">Rebobinadeira 16</option>
            <option value="REF01">Refiladeira 01</option>
            <option value="REF02">Refiladeira 02</option>
            <option value="REF03">Refiladeira 03</option>
            <option value="REF04">Refiladeira 04</option>
            <option value="REF05">Refiladeira 05</option>
        </select>
    </div>
    <div class="report-grid-4">
        Operador<br>
        <input type="text" name="operador" placeholder="NOME OPERADOR">
    </div>

    <div style="clear: both"></div>

    <div style="text-align: center">
        <input type="submit" value="Gerar Relatório">
        <a class="button" href="<?= BASE_URL?>/reports">VOLTAR</a>
    </div>

</form>

<script type="text/javascript" src="<?=BASE_URL?>/assets/js/script_report_limpeza.js"></script>