<h1>Relatórios de Produção Sintetica</h1>

<form onsubmit="return openPopup(this)">

    <div class="report-grid-4">
        Data Inicial<br>
        <input type="date" name="producao_data_inicial" value="<?php echo date("Y-m-d") ?>">
    </div>

    <div class="report-grid-4">
        Data Final<br>
        <input type="date" name="producao_data_final" value="<?php echo date("Y-m-d") ?>">
    </div>

    <div class="report-grid-4">
       Pedido<br>
        <input type="text" name="pedido" placeholder="Numero do Pedido">
    </div>
   
    <div class="report-grid-4">
       Lote<br>
        <input type="text" name="lote" placeholder="Lote Interno">
    </div>

    <div class="report-grid-4">
        Extrusora<br>
        <select name="ext">
            <option selected value="">ESCOLHA A EXTRUSORA</option>
            <option value="01">01</option>
            <option value="02">02</option>
            <option value="03">03</option>
            <option value="04">04</option>
            <option value="05">05</option>
        </select>
    </div>

     <div class="report-grid-4">
        Turno<br>
        <select name="turno">
            <option selected value="">ESCOLHA O TURNO</option>
            <option value="001">MANHA</option>
            <option value="002">TARDE</option>
            <option value="003">NOITE</option>            
        </select>
    </div>

    <div style="clear: both"></div>

    <div style="text-align: center">
        <input type="submit" value="Gerar Relatório">
        <a class="button" href="<?= BASE_URL?>/reports">VOLTAR</a>
    </div>

</form>

<script type="text/javascript" src="<?=BASE_URL?>/assets/js/script_report_producao.js"></script>